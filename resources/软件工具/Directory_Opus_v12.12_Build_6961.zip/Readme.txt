1. Uninstall any Previous Installation Using Iobit/Revo Uninstaller. & Restart PC.
2. Install Program. 
3. Open "FIX" Folder & Run "Fix-DeLtA.cmd" As ADMIN [IMP!].
4. Open Directory Opus Application & Install Certificate Inside, "Certificate" Folder.
5. Done. Enjoy :)

Consider Disabling Automatic Updates Via Settings->Preferences->Internet->Updates.

1.安装 DOpusInstall.exe

2.Crack目录下运行 "FIX-DeLtA.cmd" 脚本（其他是三个文件是替换文件），运行之前行查看一下脚本中替换的路径。
这个与DOpusInstall.exe安装路径有关，结合自己的实际情况修改。

3.打开Certificate目录下的"Directory Opus Program Certificate.opuscert"，确认安装。

4.查看证书状态。

