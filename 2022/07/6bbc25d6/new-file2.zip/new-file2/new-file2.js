#!/usr/bin/env node
const { sep, join, dirname } = require('path');
const { readFile, writeFile } = require('fs');


//获取文件命令（带后缀）
let fileNameAndExt = process.argv.splice(2)[0];
//获取执行命令的路径（即新创建文件的路径）
let fileDir = process.cwd()+ sep;
//如果参数不为空
if(fileNameAndExt && fileDir){
  let fileName = (fileNameAndExt.split('.'))[0]
  if(fileName){
    let date = new Date();
    //获取当前时间 24小时制
    let datetime = date.toLocaleString('chinese',{ hour12: false });
    console.log(fileNameAndExt+'    已生成...')
    //设置模板
    defaults = {
      normal: [
        '---',    
        'title: '+ fileName ,
        'date: '+ datetime ,
        'tags:',
        'categories:',      
        '---'
      ].join('\n')
    };

    //写模板
    writeFile(fileNameAndExt, defaults.normal,(error) => { 
          
      // In case of a error throw err exception. 
      if (error) throw err; });
      }
}
 