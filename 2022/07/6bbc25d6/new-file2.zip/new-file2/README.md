---
title: README
date: 2022/7/23 19:57:39
tags:
categories:
---

## 在package.json 中加入以下代码
  "bin": {
    "new": "new-file.js"
  },