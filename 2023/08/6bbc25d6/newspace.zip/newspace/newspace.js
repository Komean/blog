#!/usr/bin/env node
const { sep, join, dirname } = require('path');
const { readFile, writeFile } = require('fs');


//获取执行命令的路径（即新创建文件的路径）
let fileDir = process.cwd()+ sep;


let fileDir_creant_new1 = fileDir + '内容1：合同';
let fileDir_creant_new2 = fileDir + '内容2：OA公文[含邮件]';
let fileDir_creant_new3 = fileDir + '内容3：项目采购[含议题、签报]';
let fileDir_creant_new4 = fileDir + '内容4：事务处理';
let fileDir_creant_new5 = fileDir + '内容5：其他文档[模版、统计表：word、excel、ppt]';

let fs = require('fs');
fs.mkdir(fileDir_creant_new1,(err)=>{
  if(err){
    console.log('内容1：合同 目录创建失败')
  }else{
    console.log('内容1：合同 目录创建成功')
  }
})

fs.mkdir(fileDir_creant_new2,(err)=>{
  if(err){
    console.log('内容2：OA公文[含邮件] 目录创建失败')
  }else{
    console.log('内容2：OA公文[含邮件] 目录创建成功')
  }
})

fs.mkdir(fileDir_creant_new3,(err)=>{
  if(err){
    console.log('内容3：项目采购[含议题、签报] 目录创建失败')
  }else{
    console.log('内容3：项目采购[含议题、签报] 目录创建成功')
  }
})

fs.mkdir(fileDir_creant_new4,(err)=>{
  if(err){
    console.log('内容4：事务处理 目录创建失败')
  }else{
    console.log('内容4：事务处理 目录创建成功')
  }
})

fs.mkdir(fileDir_creant_new5,(err)=>{
  if(err){
    console.log('内容5：其他文档[模版、统计表：word、excel、ppt] 目录创建失败')
  }else{
    console.log('内容5：其他文档[模版、统计表：word、excel、ppt] 目录创建成功')
  }
})
