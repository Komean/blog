#!/usr/bin/env node
const { sep, join, dirname } = require('path');
const { readFile, writeFile } = require('fs');


//获取执行命令的路径（即新创建文件的路径）
let fileDir = process.cwd()+ sep;

let fileDirTransaction = fileDir + "事务处理";

let fs = require('fs');

fs.mkdir(fileDirTransaction,(err)=>{
  if(err){
    console.log('事务处理 目录创建失败')
  }else{
    console.log('事务处理 目录创建成功')
  }
})

let fileDir_creant_new1 = fileDirTransaction + sep + '1.Reference[参考资料]';
let fileDir_creant_new2 = fileDirTransaction + sep + '2.Collection[各级反馈]';
let fileDir_creant_new3 = fileDirTransaction + sep + '3.Output[结果输出]';
let fileDir_creant_new4 = fileDir_creant_new2 + sep + '0.Backups[备份]';


fs.mkdir(fileDir_creant_new1,(err)=>{
  if(err){
    console.log('1.Reference[参考资料] 目录创建失败')
  }else{
    console.log('1.Reference[参考资料] 目录创建成功')
  }
})

fs.mkdir(fileDir_creant_new2,(err)=>{
  if(err){
    console.log('2.Collection[各级反馈] 目录创建失败')
  }else{
    console.log('2.Collection[各级反馈] 目录创建成功')
  }
})

fs.mkdir(fileDir_creant_new3,(err)=>{
  if(err){
    console.log('3.Output[结果输出] 目录创建失败')
  }else{
    console.log('3.Output[结果输出] 目录创建成功')
  }
})

fs.mkdir(fileDir_creant_new4,(err)=>{
  if(err){
    console.log('0.Backups[备份] 目录创建失败')
  }else{
    console.log('0.Backups[备份] 目录创建成功')
  }
})
